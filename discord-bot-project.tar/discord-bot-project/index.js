
import { Client, GatewayIntentBits } from "discord.js";
import express from "express";

const app = express();
app.use(express.static("./website"));

app.listen(3000, () => {
  console.log("🌐 Website running on port 3000");
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

const PREFIX = "!";

client.once("ready", () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
});

client.on("messageCreate", message => {
  if (message.author.bot) return;
  if (!message.content.startsWith(PREFIX)) return;

  const args = message.content.slice(PREFIX.length).trim().split(/ +/);
  const cmd = args.shift().toLowerCase();

  if (cmd === "ping") message.reply("🏓 Pong!");
  if (cmd === "help") message.reply("!ping | !help");
});

client.login(process.env.TOKEN);
